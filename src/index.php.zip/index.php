<?php
echo phpinfo();
$developer_name = "Artamonov Artemij";
$developer_email = "array.clean@gmail.com";
?>

<h1><? echo $developer_name  ?></h1>
<h2><? echo $developer_email ?></h2>


